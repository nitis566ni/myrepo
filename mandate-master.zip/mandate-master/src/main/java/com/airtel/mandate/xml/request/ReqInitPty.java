package com.airtel.mandate.xml.request;

public class ReqInitPty {
	private Info info;

	public Info getInfo() {
		return info;
	}

	public void setInfo(Info info) {
		this.info = info;
	}
	
}
