package com.airtel.mandate.validator;

import java.io.IOException;

import com.airtel.mandate.xml.request.CrAccDtl;
import com.airtel.mandate.xml.request.Dbtr;
import com.airtel.mandate.xml.request.GrpHdr;
import com.airtel.mandate.xml.request.Info;
import com.airtel.mandate.xml.request.Mndt;
import com.airtel.mandate.xml.request.MndtAuthReq;
import com.airtel.mandate.xml.request.Ocrncs;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;

public class XmlMandateAuthRequestValidator {
	public static final String XML_FILE = "records.xml";
	public static final String SCHEMA_FILE = "records.xsd";

	public static void main(String[] args) {
		XmlMandateAuthRequestValidator XMLValidator = new XmlMandateAuthRequestValidator();
		boolean valid = XMLValidator.validateXML(XML_FILE, SCHEMA_FILE);

		System.out.printf("%s validation = %b.", XML_FILE, valid);
	}

	public boolean validateXML(String xmlFile, String schemaFile) {
		SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		try {
			Schema schema = schemaFactory.newSchema(new File(getResource(schemaFile)));

			Validator validator = schema.newValidator();
			validator.validate(new StreamSource(new File(getResource(xmlFile))));
			return true;
		} catch (SAXException | IOException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean validateMandateReq(MndtAuthReq req) {
		boolean isReqValid = true;

		if (req != null) {
			if (req.getGrpHdr() != null) {
				GrpHdr grpHdr = req.getGrpHdr();
				if (grpHdr.getNPCI_RefMsgId() == null || grpHdr.getNPCI_RefMsgId().isEmpty()) {
					isReqValid = false;
				}
				if (grpHdr.getCreDtTm() == null) {
					isReqValid = false;
				}
				if (grpHdr.getReqInitPty() != null) {
					if (grpHdr.getReqInitPty().getInfo() != null) {
						Info info = grpHdr.getReqInitPty().getInfo();
						if (info.getCatCode() == null || info.getCatCode().isEmpty()) {
							isReqValid = false;
						}
						if (info.getCatDesc() == null || info.getCatDesc().isEmpty()) {
							isReqValid = false;
						}
						if (info.getId() == null || info.getId().isEmpty()) {
							isReqValid = false;
						}
						if (info.getName() == null || info.getName().isEmpty()) {
							isReqValid = false;
						}
						if (info.getSpn_Bnk_Nm() == null || info.getSpn_Bnk_Nm().isEmpty()) {
							isReqValid = false;
						}
						if (info.getUtilCode() == null) {
							isReqValid = false;
						}
					} else {
						isReqValid = false;
					}
				} else {
					isReqValid = false;
				}
			} else {
				isReqValid = false;
			}

			if (req.getMndt() != null) {
				Mndt mndt = req.getMndt();
				if (mndt.getMndtReqId() == null || mndt.getMndtReqId().isEmpty()) {
					isReqValid = false;
				}
				if (mndt.getMndtId() == null || mndt.getMndtId().isEmpty()) {
					isReqValid = false;
				}
				if (mndt.getMndt_Type() == null || mndt.getMndt_Type().isEmpty()) {
					isReqValid = false;
				}

				if (mndt.getOcrncs() != null) {
					Ocrncs ocrncs = mndt.getOcrncs();
					if (ocrncs.getSeqTp() == null || ocrncs.getSeqTp().isEmpty()) {
						isReqValid = false;
					}
				} else {
					isReqValid = false;
				}

				if (mndt.getDbtr() != null) {
					Dbtr dbtr = mndt.getDbtr();
					if (dbtr.getNm() == null || dbtr.getNm().isEmpty()) {
						isReqValid = false;
					}
					if (dbtr.getAccNo() == null || dbtr.getAccNo().isEmpty()) {
						isReqValid = false;
					}
					if (dbtr.getAcct_Type() == null || dbtr.getAcct_Type().isEmpty()) {
						isReqValid = false;
					}
				} else {
					isReqValid = false;
				}

				if (mndt.getCrAccDtl() != null) {
					CrAccDtl crAccDtl = mndt.getCrAccDtl();
					if (crAccDtl.getNm() == null || crAccDtl.getNm().isEmpty()) {
						isReqValid = false;
					}
					if (crAccDtl.getAccNo() == null || crAccDtl.getAccNo().isEmpty()) {
						isReqValid = false;
					}
					if (crAccDtl.getMmbId() == null || crAccDtl.getMmbId().isEmpty()) {
						isReqValid = false;
					}

				} else {
					isReqValid = false;
				}
			} else {
				isReqValid = false;
			}
		} else {
			isReqValid = false;
		}

		return isReqValid;
	}

	private String getResource(String filename) throws FileNotFoundException {
		URL resource = getClass().getClassLoader().getResource(filename);
		Objects.requireNonNull(resource);

		return resource.getFile();
	}
}
